# Landing_Page_Project
Task Details:- The layout of this landing page is created using HTML which includes nav-bar, homepage body section & footer having the copyright. Also this page is styled using CSS & it's properties which controls the visual appearance of elements on the web page.Through this task I learned a lot of new things!!! 
